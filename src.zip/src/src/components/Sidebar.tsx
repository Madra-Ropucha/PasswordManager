import { useEffect, useMemo, useState } from "react";
import type { Category } from "../models/types";

type Props = {
  categories: Category[];
  activeCategoryId: string;
  onSelectCategory: (id: string) => void;
};

type TreeNode = Category & { children: TreeNode[] };

function buildTree(categories: Category[]): TreeNode[] {
  const byId = new Map<string, TreeNode>();
  for (const c of categories) byId.set(c.id, { ...c, children: [] });

  const roots: TreeNode[] = [];
  for (const c of categories) {
    const node = byId.get(c.id)!;
    const parentId = c.parentId;
    if (parentId && byId.has(parentId)) byId.get(parentId)!.children.push(node);
    else roots.push(node);
  }

  const sortRec = (nodes: TreeNode[]) => {
    nodes.sort((a, b) => a.name.localeCompare(b.name));
    for (const n of nodes) sortRec(n.children);
  };
  sortRec(roots);

  return roots;
}

function ancestorPath(categories: Category[], id: string): string[] {
  const byId = new Map(categories.map((c) => [c.id, c] as const));
  const out: string[] = [];
  let cur = byId.get(id);
  while (cur?.parentId) {
    out.push(cur.parentId);
    cur = byId.get(cur.parentId);
  }
  return out;
}

function Chevron({ open }: { open: boolean }) {
  return (
    <svg
      className={"treeChevron " + (open ? "treeChevronOpen" : "")}
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <path
        d="M9 6l6 6-6 6"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

function FolderIcon({ open }: { open: boolean }) {
  // Icono tipo "folder" con trazo grueso (similar al estilo de la captura)
  if (open) {
    return (
      <svg className="treeFolder" viewBox="0 0 24 24" aria-hidden="true">
        <path
          d="M3.5 9.5h17.5c.9 0 1.6.8 1.4 1.7l-1.6 8.4c-.1.7-.8 1.2-1.5 1.2H6.2c-.7 0-1.3-.5-1.5-1.2L2.2 10.9c-.2-1 .6-1.9 1.3-1.4z"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinejoin="round"
        />
        <path
          d="M3.8 9.5V7.8c0-1.2 1-2.2 2.2-2.2h3.4l1.7 1.7h7.1c1.2 0 2.2 1 2.2 2.2"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </svg>
    );
  }

  return (
    <svg className="treeFolder" viewBox="0 0 24 24" aria-hidden="true">
      <path
        d="M3.8 8.2c0-1.2 1-2.2 2.2-2.2h3.4l1.7 1.7h7.1c1.2 0 2.2 1 2.2 2.2v8.3c0 1.2-1 2.2-2.2 2.2H6c-1.2 0-2.2-1-2.2-2.2V8.2z"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function Sidebar({ categories, activeCategoryId, onSelectCategory }: Props) {
  const tree = useMemo(() => buildTree(categories), [categories]);

  const [expanded, setExpanded] = useState<Set<string>>(() => {
    return new Set(ancestorPath(categories, activeCategoryId));
  });

  useEffect(() => {
    const path = ancestorPath(categories, activeCategoryId);
    setExpanded((prev) => {
      const next = new Set(prev);
      for (const id of path) next.add(id);
      return next;
    });
  }, [activeCategoryId, categories]);

  const toggle = (id: string) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const renderNode = (node: TreeNode, depth: number) => {
    const hasChildren = node.children.length > 0;
    const isOpen = expanded.has(node.id);
    const isActive = node.id === activeCategoryId;

    return (
      <div key={node.id} role="treeitem" aria-expanded={hasChildren ? isOpen : undefined}>
        <div
          className={"treeRow " + (isActive ? "treeRowActive" : "")}
          style={{ paddingLeft: 8 + depth * 16 }}
        >
          {hasChildren ? (
            <button
              className="treeCaretBtn"
              aria-label={isOpen ? "Contraer" : "Expandir"}
              onClick={(e) => {
                e.stopPropagation();
                toggle(node.id);
              }}
              type="button"
            >
              <Chevron open={isOpen} />
            </button>
          ) : (
            <div className="treeCaretSpacer" />
          )}

          <div className="treeIcon" aria-hidden="true">
            <FolderIcon open={hasChildren && isOpen} />
          </div>

          <button
            className="treeLabelBtn"
            onClick={() => onSelectCategory(node.id)}
            type="button"
          >
            {node.name}
          </button>
        </div>

        {hasChildren && isOpen && (
          <div className="treeChildren" role="group">
            {node.children.map((ch) => renderNode(ch, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <aside className="sidebar">
      <div className="brand">📓 Libreta</div>

      <div className="sectionTitle">Categorías</div>
      <div className="tree" role="tree" aria-label="Categorías">
        {tree.map((n) => renderNode(n, 0))}
      </div>
    </aside>
  );
}
